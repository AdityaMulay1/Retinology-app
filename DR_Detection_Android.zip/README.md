# DR Detection AI - Android Package

## Installation on Android

1. Install Python 3.7+ on your Android device
2. Install Termux or similar terminal app
3. Copy this folder to your device
4. Run: python setup.py
5. Run: python main.py

## Features

- AI-powered diabetic retinopathy detection
- 5 severity levels classification
- Demo images included
- Offline operation

## Requirements

- Python 3.7+
- Kivy framework
- Android device with 2GB+ RAM

## Usage

1. Launch the app: python main.py
2. Upload retinal images or try demo
3. Get instant AI diagnosis
4. View results and recommendations

## Medical Disclaimer

This app is for screening purposes only. 
Always consult qualified medical professionals.
