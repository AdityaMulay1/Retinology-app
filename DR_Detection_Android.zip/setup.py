#!/usr/bin/env python3
"""
Setup script for DR Detection AI on Android
"""

import os
import sys

def setup_app():
    """Setup the app on Android device"""
    
    print("Setting up DR Detection AI...")
    
    # Check Python version
    if sys.version_info < (3, 7):
        print("Python 3.7+ required")
        return False
    
    # Install Kivy if not present
    try:
        import kivy
        print("Kivy found")
    except ImportError:
        print("Installing Kivy...")
        os.system("pip install kivy")
    
    print("Setup complete!")
    print("Run: python main.py")
    return True

if __name__ == "__main__":
    setup_app()
